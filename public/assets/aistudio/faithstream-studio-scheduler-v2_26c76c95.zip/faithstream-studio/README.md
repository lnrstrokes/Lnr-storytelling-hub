# FaithStream 24/7 & Scripture Blitz Studio

A mobile-first, local-first PWA prototype for church video-loop presentation, Mystery Biblical Figure games, and Scripture Memory Blitzes.

## Run locally
1. Install Node.js (18+ recommended).
2. Run `npm install`.
3. Run `npm run dev`.
4. Open the local Vite address in a browser.

## Build
- `npm run build`
- `npm run preview`

## Included
- React + Vite frontend, responsive CSS, Lucide icons.
- Video and audio upload stored in IndexedDB on the current device.
- Local church profile and JSON datasets stored in localStorage.
- Mystery Bible game with four progressive clues, points, timer, reveal, and dataset import/export.
- Scripture Blitz with blanked keywords, letter hints, timer, reveal, and dataset import/export.
- Synthesized ambient chord pad and uploaded audio loop.
- **Automatic Programme Scheduler:** repeating playlist for sermon videos, worship/background videos, Mystery Bible rounds, and Scripture Blitz rounds. Configure segment order and duration, upload a separate video for each sermon/worship segment, then start or pause the rotation. Playlist settings and uploaded segment media persist locally in the browser. Pause keeps the position and remaining time; Resume continues from there (or restart from the first segment). Timing uses real clock timestamps, so throttled timers do not cause drift, and the app requests a screen wake lock where the browser supports it. Removing a segment also deletes its stored video.
- PWA manifest and basic service worker app-shell cache.

## Important constraints
- This is a local presentation engine, not an RTMP broadcaster. To send the presentation to YouTube Live or TikTok Live, use the platform's supported mobile screen-broadcast workflow or an external encoder.
- The Programme Scheduler is a foreground-browser timer, not an operating-system scheduler. Mobile browsers can suspend playback and timers when backgrounded, locked, or under battery-saving policies. A 24/7 uptime guarantee is not possible from a browser-only PWA. Keep the app visible, device powered, screen awake, and test on the exact device before a live church service.
- Browser storage is device- and origin-specific. Export JSON packs and keep original media files backed up separately.
- The demo's built-in verse wording is KJV-style seed content. Verify translation, punctuation, and references before public use. Imported content should be human-reviewed.
- The starter UI uses a Google Fonts import as a visual enhancement; remove it from `src/style.css` if fully offline font rendering is required.
- No payment processor, user accounts, cloud backup, or direct streaming integration is connected.

- Dependencies are pinned to exact versions. Run `npm install` once and keep the generated `package-lock.json` with the project.
